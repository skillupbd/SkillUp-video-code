// theme.ts - the ONLY place for colors, easings, springs and fonts.
// Palette: "SkillUp Signature" (approved by the user).
import {Easing} from 'remotion';
import {fontFamily} from './fonts';

export const theme = {
  colors: {
    bg: '#F5F8FC',
    bgAlt: '#E7EEF8',
    surface: '#FFFFFF',
    primary: '#12285C', // hero (navy)
    accent: '#F58A25', // accent (orange)
    text: '#0E1B3D',
    textDim: '#5A6A8A',
    line: '#D3DEEE',
    onPrimary: '#F5F8FC',
    primarySoft: 'rgba(18, 40, 92, 0.08)',
    accentSoft: 'rgba(245, 138, 37, 0.22)',
    glow: 'rgba(245, 138, 37, 0.38)',
    gloss: 'rgba(255, 255, 255, 0.55)',
    vignette: 'rgba(14, 27, 61, 0.12)',
    gradeShadow: 'rgba(14, 27, 61, 0.08)',
  },
  fonts: {display: fontFamily, body: fontFamily},
  radius: {card: 36, tile: 24, pill: 999},
  shadow: {
    card: '0 34px 60px -26px rgba(18, 40, 92, 0.30), 0 2px 8px rgba(18, 40, 92, 0.06)',
    soft: '0 18px 36px -18px rgba(18, 40, 92, 0.25)',
    glow: '0 0 60px rgba(245, 138, 37, 0.38)',
  },
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
  },
  spring: {
    snappy: {damping: 14, stiffness: 160, mass: 0.6},
    smooth: {damping: 20, stiffness: 90, mass: 1},
    bouncy: {damping: 11, stiffness: 170, mass: 0.7},
  },
} as const;
