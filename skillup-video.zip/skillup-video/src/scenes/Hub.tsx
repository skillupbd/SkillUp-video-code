import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {theme} from '../theme';
import {Entrance, WordReveal, useIdle, useRamp, useSpringAt} from '../components/Motion';
import {DrawLine, IconName, IconTile, Label, Logo, cardStyle, centerAt} from '../components/ui';
import {useCue} from '../lib/timing';

const HUB = {x: 960, y: 570};
const NODES: {x: number; y: number; icon: IconName; title: string; sub: string}[] = [
  {x: 430, y: 430, icon: 'box', title: 'ইন্টারন্যাশনাল ড্রপশিপিং', sub: 'International Dropshipping'},
  {x: 1490, y: 430, icon: 'briefcase', title: 'ডিজিটাল ওয়ার্ক', sub: 'Digital Work'},
  {x: 960, y: 925, icon: 'globe', title: 'ডিজিটাল সার্ভিসেস', sub: 'Digital Services'},
];

const Spoke: React.FC<{x: number; y: number; delay: number}> = ({x, y, delay}) => {
  const frame = useCurrentFrame();
  const p = useRamp(delay - 6, delay + 18, 'out');
  const q = ((frame - delay) % 70) / 70;
  const e = 1 - Math.pow(1 - Math.max(0, q), 2);
  return (
    <g>
      <g opacity={0.35}>
        <DrawLine d={`M ${HUB.x} ${HUB.y} L ${x} ${y}`} progress={p} width={5} />
      </g>
      {frame > delay + 18 && (
        <circle cx={HUB.x + (x - HUB.x) * e} cy={HUB.y + (y - HUB.y) * e} r={9} fill={theme.colors.accent} />
      )}
    </g>
  );
};

const NodeCard: React.FC<(typeof NODES)[number] & {delay: number}> = ({x, y, icon, title, sub, delay}) => {
  const idle = useIdle(30, x);
  return (
    <div style={centerAt(x, y + idle * 4)}>
      <Entrance delay={delay} y={30} kind="bouncy" scaleFrom={0.8}>
        <div style={{...cardStyle(), width: 600, padding: '22px 30px', display: 'flex', alignItems: 'center', gap: 26}}>
          <IconTile name={icon} size={96} dark />
          <div>
            <Label size={40}>{title}</Label>
            <Label size={26} weight={500} color={theme.colors.textDim}>{sub}</Label>
          </div>
        </div>
      </Entrance>
    </div>
  );
};

export const Hub: React.FC = () => {
  const t = useCue();
  const idle = useIdle(24);
  const hub = useSpringAt(0, 'bouncy');
  return (
    <AbsoluteFill>
      <div style={{position: 'absolute', left: 0, width: 1920, top: 60}}>
        <WordReveal text="স্কিল আপ থেকে যা *শিখবেন*" size={78} delay={2} />
      </div>
      <svg width={1920} height={1080} style={{position: 'absolute', left: 0, top: 0}}>
        {NODES.map((n, i) => (
          <Spoke key={i} x={n.x} y={n.y} delay={t(4, i / 3) + 6} />
        ))}
      </svg>
      <div
        style={{
          ...centerAt(HUB.x, HUB.y),
          transform: `translate(-50%, -50%) scale(${hub * (1 + idle * 0.015)})`,
          filter: `drop-shadow(0 0 36px ${theme.colors.glow})`,
        }}
      >
        <Logo size={260} />
      </div>
      {NODES.map((n, i) => (
        <NodeCard key={i} {...n} delay={t(4, i / 3) + 6} />
      ))}
    </AbsoluteFill>
  );
};
