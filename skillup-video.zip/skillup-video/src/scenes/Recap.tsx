import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {theme} from '../theme';
import {Entrance, WordReveal, useIdle, useRamp, useSpringAt} from '../components/Motion';
import {DrawLine, Icon, Label, Logo, cardStyle, centerAt} from '../components/ui';
import {useCue} from '../lib/timing';

const ROWS = ['ড্রপশিপিং', 'ডিজিটাল ওয়ার্ক', 'ডিজিটাল সার্ভিসেস'];

const Row: React.FC<{label: string; y: number; delay: number}> = ({label, y, delay}) => {
  const tick = useSpringAt(delay + 12, 'bouncy');
  return (
    <div style={{position: 'absolute', left: 160, top: y}}>
      <Entrance delay={delay} x={-60} y={0} kind="snappy">
        <div style={{...cardStyle(), width: 860, height: 140, boxSizing: 'border-box', padding: '0 40px', display: 'flex', alignItems: 'center', justifyContent: 'space-between'}}>
          <Label size={60}>{label}</Label>
          <div style={{width: 76, height: 76, borderRadius: '50%', background: theme.colors.primary, display: 'flex', alignItems: 'center', justifyContent: 'center', transform: `scale(${tick})`}}>
            <Icon name="check" size={44} color={theme.colors.surface} stroke={2.8} />
          </div>
        </div>
      </Entrance>
    </div>
  );
};

export const Recap: React.FC = () => {
  const frame = useCurrentFrame();
  const t = useCue();
  const idle = useIdle(26);
  const c17 = t(17, 0);
  const gridOut = useRamp(c17 - 2, c17 + 10, 'in');
  const logo = useSpringAt(c17 + 6, 'bouncy');
  const journey = useRamp(c17 + 24, c17 + 70, 'out');
  const dot = interpolate(journey, [0, 1], [0, 1]);

  return (
    <AbsoluteFill>
      <div
        style={{
          position: 'absolute', inset: 0, opacity: 1 - gridOut,
          transform: `translateY(${-gridOut * 40}px) scale(${1 - gridOut * 0.04})`,
          display: frame > c17 + 12 ? 'none' : 'block',
        }}
      >
        <div style={{position: 'absolute', left: 160, top: 70, width: 1200}}>
          <WordReveal text="আপনি যদি *চান*" size={76} delay={2} align="flex-start" />
        </div>
        {ROWS.map((r, i) => (
          <Row key={r} label={r} y={250 + i * 190} delay={t(16, i / 4)} />
        ))}
        <div style={{position: 'absolute', left: 1130, top: 250, width: 630, height: 520}}>
          <Entrance delay={t(16, 0.75)} y={50} kind="bouncy" scaleFrom={0.88} style={{width: '100%', height: '100%'}}>
            <div style={{...cardStyle(true), width: '100%', height: '100%', boxSizing: 'border-box', padding: 50, display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: 26, boxShadow: theme.shadow.glow}}>
              <Icon name="trend" size={150} color={theme.colors.accent} stroke={1.8} />
              <Label size={70} color={theme.colors.onPrimary}>কেরিয়ারের নতুন সম্ভাবনা</Label>
            </div>
          </Entrance>
        </div>
      </div>

      {/* cue 17: SkillUp as the learning companion */}
      <div
        style={{
          ...centerAt(560, 520 + idle * 5), opacity: Math.min(1, logo * 1.4),
          transform: `translate(-50%, -50%) scale(${logo})`,
          filter: `drop-shadow(0 0 36px ${theme.colors.glow})`,
        }}
      >
        <Logo size={430} />
      </div>
      <div style={{position: 'absolute', left: 940, top: 330, width: 840}}>
        <WordReveal text="স্কিল আপ আপনার শেখার যাত্রার *সঙ্গী*" size={84} delay={c17 + 10} align="flex-start" />
      </div>
      <svg width={1920} height={1080} style={{position: 'absolute', left: 0, top: 0}}>
        <g opacity={0.35}>
          <DrawLine d="M 960 790 C 1180 700, 1380 880, 1760 760" progress={journey} width={6} />
        </g>
        {journey > 0.02 && (
          <circle cx={960 + dot * 800} cy={790 - Math.sin(dot * Math.PI) * 40 + dot * -30} r={12} fill={theme.colors.accent} />
        )}
      </svg>
    </AbsoluteFill>
  );
};
