import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {theme} from '../theme';
import {Entrance, WordReveal, useIdle, useRamp, useSpringAt} from '../components/Motion';
import {Cursor, Icon, Label, Logo, centerAt} from '../components/ui';
import {useCue} from '../lib/timing';

export const Cta: React.FC = () => {
  const frame = useCurrentFrame();
  const t = useCue();
  const idle = useIdle(26);
  const click = t(18, 0.55);
  const c19 = t(19, 0);

  const cursorIn = useRamp(t(18, 0.2), click - 2, 'inOut');
  const press = interpolate(frame, [click, click + 4, click + 12], [0, 1, 0], {
    extrapolateLeft: 'clamp', extrapolateRight: 'clamp',
  });
  const ripple = useRamp(click, click + 26, 'out');
  const phase1Out = useRamp(c19 - 2, c19 + 8, 'in');
  const logo = useSpringAt(c19 + 4, 'bouncy');
  const sparkle = useRamp(c19 + 6, c19 + 44, 'out');

  return (
    <AbsoluteFill>
      <div
        style={{
          position: 'absolute', inset: 0, opacity: 1 - phase1Out,
          transform: `translateY(${-phase1Out * 40}px)`,
          display: frame > c19 + 10 ? 'none' : 'block',
        }}
      >
        <div style={{position: 'absolute', left: 0, width: 1920, top: 150}}>
          <WordReveal text="আজই *যুক্ত হন*" size={150} delay={2} />
        </div>
        <div style={{position: 'absolute', left: 0, width: 1920, top: 350}}>
          <WordReveal text="স্কিল আপ কমিউনিটিতে" size={76} weight={600} color={theme.colors.primary} delay={14} />
        </div>

        <div style={centerAt(960, 640)}>
          <Entrance delay={22} y={40} kind="bouncy" scaleFrom={0.85}>
            <div style={{position: 'relative'}}>
              <div
                style={{
                  position: 'absolute', inset: 0, borderRadius: theme.radius.pill,
                  border: `5px solid ${theme.colors.accent}`, opacity: ripple > 0 ? (1 - ripple) * 0.7 : 0,
                  transform: `scale(${1 + ripple * 0.35})`,
                }}
              />
              <div
                style={{
                  display: 'flex', alignItems: 'center', gap: 26, padding: '34px 76px',
                  borderRadius: theme.radius.pill, background: theme.colors.accent,
                  boxShadow: theme.shadow.glow, transform: `scale(${1 - press * 0.06})`,
                }}
              >
                <Icon name="users" size={64} color={theme.colors.surface} stroke={2} />
                <Label size={72} color={theme.colors.surface}>কমিউনিটিতে যুক্ত হন</Label>
              </div>
            </div>
          </Entrance>
          <div style={{position: 'absolute', left: 600 + (1 - cursorIn) * 380, top: 78 + (1 - cursorIn) * 150, opacity: Math.min(1, cursorIn * 4)}}>
            <Cursor size={70} />
          </div>
        </div>

        <div style={{position: 'absolute', left: 0, width: 1920, top: 840}}>
          <WordReveal text="শুরু করুন আপনার *ডিজিটাল যাত্রা*" size={68} delay={click + 6} color={theme.colors.text} />
        </div>
      </div>

      {/* cue 19: brand lockup */}
      <div
        style={{
          ...centerAt(960, 360 + idle * 4),
          opacity: Math.min(1, logo * 1.4), transform: `translate(-50%, -50%) scale(${logo})`,
          filter: `drop-shadow(0 0 44px ${theme.colors.glow})`,
        }}
      >
        <Logo size={460} />
      </div>
      <div
        style={{
          ...centerAt(960, 360), width: 460, height: 460, borderRadius: '50%',
          border: `6px solid ${theme.colors.accent}`, opacity: sparkle > 0 ? (1 - sparkle) * 0.55 : 0,
          transform: `translate(-50%, -50%) scale(${1 + sparkle * 0.8})`,
        }}
      />
      <div style={{position: 'absolute', left: 0, width: 1920, top: 690, display: 'flex', justifyContent: 'center', gap: 56}}>
        {['লার্ন', 'গ্রো', 'লেভেল আপ'].map((w, i) => (
          <Entrance key={w} delay={c19 + 14 + i * 5} y={30} kind="snappy">
            <Label size={96} color={i === 2 ? theme.colors.accent : theme.colors.primary}>{w}</Label>
          </Entrance>
        ))}
      </div>
      <Entrance delay={c19 + 34} y={14} style={{position: 'absolute', left: 0, width: 1920, top: 850, display: 'flex', justifyContent: 'center'}}>
        <Label size={44} weight={500} color={theme.colors.textDim}>Learn · Grow · Level Up</Label>
      </Entrance>
    </AbsoluteFill>
  );
};
