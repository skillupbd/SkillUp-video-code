import React from 'react';
import {AbsoluteFill, interpolate} from 'remotion';
import {theme} from '../theme';
import {WordReveal, useRamp, useSpringAt} from '../components/Motion';
import {centerAt} from '../components/ui';

export const Think: React.FC = () => {
  const open = useRamp(0, 20, 'out');
  const q = useSpringAt(16, 'bouncy');
  const d = open * 2800;
  return (
    <AbsoluteFill>
      <div
        style={{
          ...centerAt(960, 540), width: d, height: d, borderRadius: '50%',
          background: theme.colors.primary,
        }}
      />
      <div style={{...centerAt(900, 540), display: 'flex', alignItems: 'center'}}>
        <WordReveal text="ভাবুন তো" size={230} delay={6} color={theme.colors.onPrimary} />
        <div
          style={{
            fontFamily: theme.fonts.display, fontSize: 230, fontWeight: 700, lineHeight: 1.3,
            letterSpacing: 0, color: theme.colors.accent, marginLeft: 24,
            opacity: interpolate(q, [0, 1], [0, 1], {extrapolateRight: 'clamp'}),
            transform: `scale(${q}) rotate(${(1 - q) * -25}deg)`,
          }}
        >
          ?
        </div>
      </div>
    </AbsoluteFill>
  );
};
