import React from 'react';
import {AbsoluteFill} from 'remotion';
import {theme} from '../theme';
import {Entrance, useIdle} from '../components/Motion';
import {Icon, IconName, IconTile, Label, cardStyle, centerAt} from '../components/ui';
import {useCue} from '../lib/timing';

const SideCard: React.FC<{
  x: number; delay: number; dark?: boolean; icon: IconName; tag: string;
  title: string; sub: string;
}> = ({x, delay, dark, icon, tag, title, sub}) => {
  const idle = useIdle(34, x);
  return (
    <div style={{position: 'absolute', left: x, top: 170 + idle * 4, width: 740, height: 560}}>
      <Entrance delay={delay} y={50} style={{width: '100%', height: '100%'}}>
        <div style={{...cardStyle(dark), width: '100%', height: '100%', padding: 54, position: 'relative', overflow: 'hidden', boxSizing: 'border-box'}}>
          <div style={{position: 'absolute', right: -40, bottom: -50, opacity: dark ? 0.12 : 0.06}}>
            <Icon name={icon} size={400} color={dark ? theme.colors.surface : theme.colors.primary} stroke={1.2} />
          </div>
          <div
            style={{
              display: 'inline-block', padding: '6px 28px', borderRadius: theme.radius.pill,
              background: dark ? theme.colors.accent : theme.colors.primarySoft,
            }}
          >
            <Label size={38} color={dark ? theme.colors.surface : theme.colors.textDim}>{tag}</Label>
          </div>
          <div style={{marginTop: 40}}>
            <IconTile name={icon} size={140} accent={dark} dark={!dark} />
          </div>
          <Label size={68} color={dark ? theme.colors.onPrimary : theme.colors.text} style={{marginTop: 34}}>{title}</Label>
          <Label size={32} weight={500} color={dark ? theme.colors.bgAlt : theme.colors.textDim}>{sub}</Label>
        </div>
      </Entrance>
    </div>
  );
};

export const Split: React.FC = () => {
  const t = useCue();
  return (
    <AbsoluteFill>
      <SideCard x={130} delay={t(5, 0)} icon="store" tag="শুধু" title="নিজের অনলাইন বিজনেস" sub="Your Own Online Business" />
      <SideCard x={1050} delay={t(5, 1 / 3)} dark icon="briefcase" tag="বরং" title="অন্যদের ডিজিটাল সার্ভিস" sub="Digital Services for Others" />
      <div style={centerAt(960, 450)}>
        <Entrance delay={t(5, 1 / 3)} y={0} scaleFrom={0.3} kind="bouncy">
          <div style={{width: 96, height: 96, borderRadius: '50%', background: theme.colors.accent, boxShadow: theme.shadow.glow, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
            <Icon name="arrow" size={54} color={theme.colors.surface} stroke={2.4} />
          </div>
        </Entrance>
      </div>
      <div style={centerAt(960, 880)}>
        <Entrance delay={t(5, 2 / 3)} y={40} kind="bouncy" scaleFrom={0.85}>
          <div style={{display: 'flex', alignItems: 'center', gap: 28, padding: '20px 56px', borderRadius: theme.radius.pill, background: theme.colors.primary, boxShadow: theme.shadow.card}}>
            <Icon name="trend" size={64} color={theme.colors.accent} stroke={2.2} />
            <Label size={66} color={theme.colors.onPrimary}>নিজের কেরিয়ার গড়ার সুযোগ</Label>
          </div>
        </Entrance>
      </div>
    </AbsoluteFill>
  );
};
