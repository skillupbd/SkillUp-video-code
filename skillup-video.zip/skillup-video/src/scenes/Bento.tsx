import React from 'react';
import {AbsoluteFill} from 'remotion';
import {theme} from '../theme';
import {Entrance, WordReveal, useIdle} from '../components/Motion';
import {Icon, IconName, IconTile, Label, cardStyle} from '../components/ui';
import {useCue} from '../lib/timing';

type TileProps = {
  x: number; y: number; w: number; h: number; delay: number; icon: IconName;
  title: string; sub: string; dark?: boolean; tall?: boolean;
};

const Tile: React.FC<TileProps> = ({x, y, w, h, delay, icon, title, sub, dark, tall}) => {
  const idle = useIdle(32, x + y);
  return (
    <div style={{position: 'absolute', left: x, top: y + idle * 3, width: w, height: h}}>
      <Entrance delay={delay} y={46} kind="bouncy" scaleFrom={0.88} style={{width: '100%', height: '100%'}}>
        <div style={{...cardStyle(dark), width: '100%', height: '100%', boxSizing: 'border-box', padding: 40, position: 'relative', overflow: 'hidden'}}>
          <div style={{position: 'absolute', right: -50, bottom: -60, opacity: dark ? 0.14 : 0.06}}>
            <Icon name={icon} size={tall ? 420 : 260} color={dark ? theme.colors.surface : theme.colors.primary} stroke={1.2} />
          </div>
          <IconTile name={icon} size={tall ? 150 : 100} dark={!dark} accent={dark} />
          <Label size={tall ? 66 : 46} color={dark ? theme.colors.onPrimary : theme.colors.text} style={{marginTop: tall ? 40 : 24}}>
            {title}
          </Label>
          <Label size={tall ? 32 : 26} weight={500} color={dark ? theme.colors.bgAlt : theme.colors.textDim}>
            {sub}
          </Label>
        </div>
      </Entrance>
    </div>
  );
};

export const Bento: React.FC = () => {
  const t = useCue();
  return (
    <AbsoluteFill>
      <div style={{position: 'absolute', left: 180, top: 70, width: 1200}}>
        <WordReveal text="এখানে রয়েছে *যা যা*" size={76} delay={2} align="flex-start" />
      </div>
      <Tile x={180} y={230} w={501} h={760} tall delay={t(6, 0)} icon="search" title="উইনিং প্রোডাক্ট রিসার্চ" sub="Winning Product Research" />
      <Tile x={709} y={230} w={501} h={366} delay={t(6, 1 / 3)} icon="store" title="শপফাই স্টোর ক্রিয়েশন" sub="Shopify Store Creation" />
      <Tile x={1238} y={230} w={502} h={366} delay={t(6, 2 / 3)} icon="megaphone" title="ফেসবুক ও টিকটক মার্কেটিং" sub="Facebook & TikTok Marketing" />
      <Tile x={709} y={624} w={501} h={366} delay={t(7, 0)} icon="code" title="ওয়েবসাইট ডেভেলপমেন্ট" sub="Website Development" />
      <Tile x={1238} y={624} w={502} h={366} dark delay={t(7, 0.5)} icon="plus" title="আরও বিভিন্ন ডিজিটাল কাজ ও সার্ভিস" sub="& more" />
    </AbsoluteFill>
  );
};
