import React from 'react';
import {AbsoluteFill} from 'remotion';
import {theme} from '../theme';
import {Entrance, WordReveal, useIdle, useRamp} from '../components/Motion';
import {DrawLine, Icon, IconName, IconTile, Label, cardStyle, centerAt} from '../components/ui';
import {useCue} from '../lib/timing';

const N0 = {x: 330, y: 560};
const A = {x: 1000, y: 310};
const B = {x: 1000, y: 810};
const F = {x: 1580, y: 560};

const Edge: React.FC<{d: string; start: number}> = ({d, start}) => {
  const p = useRamp(start, start + 26, 'out');
  return (
    <g opacity={0.4}>
      <DrawLine d={d} progress={p} width={6} />
    </g>
  );
};

const BranchCard: React.FC<{pos: {x: number; y: number}; icon: IconName; title: string; sub: string; delay: number}> = ({
  pos, icon, title, sub, delay,
}) => {
  const idle = useIdle(30, pos.y);
  return (
    <div style={centerAt(pos.x, pos.y + idle * 4)}>
      <Entrance delay={delay} y={30} kind="bouncy" scaleFrom={0.85}>
        <div style={{...cardStyle(), width: 520, padding: '22px 30px', boxSizing: 'border-box', display: 'flex', alignItems: 'center', gap: 24}}>
          <IconTile name={icon} size={92} dark />
          <div>
            <Label size={44}>{title}</Label>
            <Label size={26} weight={500} color={theme.colors.textDim}>{sub}</Label>
          </div>
        </div>
      </Entrance>
    </div>
  );
};

const Node: React.FC<{pos: {x: number; y: number}; accent?: boolean; icon: IconName; label: string; delay: number}> = ({
  pos, accent, icon, label, delay,
}) => {
  const idle = useIdle(26, pos.x);
  return (
    <div style={centerAt(pos.x, pos.y + idle * 5)}>
      <Entrance delay={delay} y={0} kind="bouncy" scaleFrom={0.4}>
        <div style={{display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 22}}>
          <div
            style={{
              width: accent ? 260 : 220, height: accent ? 260 : 220, borderRadius: '50%',
              background: accent ? theme.colors.accent : theme.colors.primary,
              boxShadow: accent ? theme.shadow.glow : theme.shadow.card,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}
          >
            <Icon name={icon} size={accent ? 130 : 108} color={theme.colors.surface} stroke={1.7} />
          </div>
          <Label size={50}>{label}</Label>
        </div>
      </Entrance>
    </div>
  );
};

export const Flow: React.FC = () => {
  const t = useCue();
  const tNode = t(11, 1 / 3);
  const tA = t(11, 2 / 3);
  const tB = t(12, 0);
  const tF = t(12, 0.5);
  return (
    <AbsoluteFill>
      <div style={{position: 'absolute', left: 140, top: 60, width: 900}}>
        <WordReveal text="শুধু একটি মডেলে *সীমাবদ্ধ নয়*" size={64} delay={t(11, 0)} align="flex-start" />
      </div>
      <svg width={1920} height={1080} style={{position: 'absolute', left: 0, top: 0}}>
        <Edge d="M 440 530 C 600 530, 600 310, 740 310" start={tA - 4} />
        <Edge d="M 440 590 C 600 590, 600 810, 740 810" start={tB - 4} />
        <Edge d="M 1260 310 C 1380 310, 1380 520, 1452 540" start={tF - 14} />
        <Edge d="M 1260 810 C 1380 810, 1380 600, 1452 580" start={tF - 14} />
      </svg>
      <Node pos={N0} icon="spark" label="দক্ষতা অর্জন" delay={tNode} />
      <BranchCard pos={A} icon="store" title="নিজের ব্যবসা" sub="Your Business" delay={tA} />
      <BranchCard pos={B} icon="briefcase" title="ক্লায়েন্টদের সার্ভিস" sub="Client Services" delay={tB} />
      <Node pos={F} accent icon="trend" label="ডিজিটাল কেরিয়ার" delay={tF} />
    </AbsoluteFill>
  );
};
