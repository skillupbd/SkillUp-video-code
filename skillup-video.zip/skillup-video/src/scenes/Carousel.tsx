import React from 'react';
import {AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {theme} from '../theme';
import {Entrance, WordReveal, useIdle, useRamp} from '../components/Motion';
import {Cursor, Icon, IconName, IconTile, Label, cardStyle} from '../components/ui';
import {useCue} from '../lib/timing';

const CARDS: {icon: IconName; title: string; sub: string}[] = [
  {icon: 'briefcase', title: 'বিভিন্ন কাজ', sub: 'Digital Work'},
  {icon: 'code', title: 'দক্ষতা', sub: 'Skills'},
  {icon: 'trend', title: 'সম্ভাবনা', sub: 'Opportunities'},
];

const pad2 = (n: number) => String(n).padStart(2, '0');

export const Carousel: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = useCue();
  const idle = useIdle(28);
  const sp = (at: number) => spring({frame: Math.max(0, frame - at), fps, config: theme.spring.smooth});

  // Rotation: card0 -> card1 (cue 13 mid) -> card2 (cue 14) -> back to card1 (cue 15, "choose your path")
  const rot = sp(t(13, 0.5)) + sp(t(14, 0)) + 2 * sp(t(15, 0.3));
  const current = ((Math.round(rot) % 3) + 3) % 3;
  const pick = useRamp(t(15, 0.65), t(15, 0.65) + 14, 'out');
  const cursor = useRamp(t(15, 0.4), t(15, 0.65) - 2, 'inOut');

  return (
    <AbsoluteFill>
      <div style={{position: 'absolute', left: 140, top: 70, width: 1000}}>
        <WordReveal text="আমাদের *লক্ষ্য*" size={72} delay={2} align="flex-start" />
        <Entrance delay={14} y={20}>
          <Label size={36} weight={500} color={theme.colors.textDim}>ডিজিটাল দুনিয়ার সঙ্গে পরিচিতি</Label>
        </Entrance>
      </div>

      <Entrance delay={10} y={0} style={{position: 'absolute', right: 150, top: 90}}>
        <div style={{display: 'flex', alignItems: 'baseline', gap: 12, fontVariantNumeric: 'tabular-nums'}}>
          <Label size={72} color={theme.colors.accent}>{pad2(current + 1)}</Label>
          <Label size={36} weight={500} color={theme.colors.textDim}>/ {pad2(CARDS.length)}</Label>
        </div>
      </Entrance>

      <div style={{position: 'absolute', left: 0, top: 230, width: 1920, height: 660, perspective: 2200}}>
        {CARDS.map((c, i) => {
          let d = (((i - rot) % 3) + 3) % 3;
          if (d > 1.5) d -= 3;
          const ad = Math.abs(d);
          const isFront = i === current;
          const sel = isFront ? pick : 0;
          return (
            <div
              key={i}
              style={{
                position: 'absolute', left: 960 - 290, top: 20 + idle * 4, width: 580, height: 620,
                opacity: interpolate(ad, [0, 1, 1.5], [1, 0.55, 0], {extrapolateRight: 'clamp'}),
                zIndex: Math.round(100 - ad * 10),
                transform: `translateX(${d * 700}px) translateZ(${-ad * 260}px) rotateY(${-d * 36}deg) scale(${1 - 0.1 * ad})`,
              }}
            >
              <Entrance delay={4 + i * 4} y={50} style={{width: '100%', height: '100%'}}>
                <div
                  style={{
                    ...cardStyle(), width: '100%', height: '100%', boxSizing: 'border-box', padding: 52,
                    display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 28,
                    outline: `${6 * sel}px solid ${theme.colors.accent}`, position: 'relative',
                  }}
                >
                  <IconTile name={c.icon} size={190} dark />
                  <Label size={76}>{c.title}</Label>
                  <Label size={34} weight={500} color={theme.colors.textDim}>{c.sub}</Label>
                  {sel > 0.05 && (
                    <div
                      style={{
                        position: 'absolute', right: -22, top: -22, width: 76, height: 76, borderRadius: '50%',
                        background: theme.colors.accent, boxShadow: theme.shadow.glow, transform: `scale(${sel})`,
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                      }}
                    >
                      <Icon name="check" size={44} color={theme.colors.surface} stroke={2.8} />
                    </div>
                  )}
                </div>
              </Entrance>
            </div>
          );
        })}
        <div
          style={{
            position: 'absolute', left: 1500 - cursor * 420, top: 560 - cursor * 120,
            opacity: Math.min(1, cursor * 4) * (1 - pick * 0.2), zIndex: 200,
          }}
        >
          <Cursor size={64} />
        </div>
      </div>

      <div style={{position: 'absolute', left: 0, width: 1920, top: 930}}>
        <WordReveal text="নিজের আগ্রহ অনুযায়ী *পথ বেছে* নিন" size={60} delay={t(15, 0)} />
      </div>
    </AbsoluteFill>
  );
};
