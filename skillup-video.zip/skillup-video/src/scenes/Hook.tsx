import React from 'react';
import {AbsoluteFill} from 'remotion';
import {theme} from '../theme';
import {Entrance, WordReveal, useIdle, useRamp, useSpringAt} from '../components/Motion';
import {Icon, IconTile, IconName, Label, centerAt} from '../components/ui';
import {useCue} from '../lib/timing';

const CX = 960;
const CY = 390;
const SATS: IconName[] = ['globe', 'code', 'megaphone', 'store', 'search', 'users'];

const Ring: React.FC<{start: number; i: number}> = ({start, i}) => {
  const p = useRamp(start + i * 6, start + i * 6 + 40, 'out');
  return (
    <div
      style={{
        ...centerAt(CX, CY), width: 220, height: 220, borderRadius: '50%',
        border: `4px solid ${theme.colors.primary}`, opacity: p > 0 ? (1 - p) * 0.35 : 0,
        transform: `translate(-50%, -50%) scale(${1 + p * (2.4 + i * 0.9)})`,
      }}
    />
  );
};

export const Hook: React.FC = () => {
  const t = useCue();
  const idle = useIdle(26);
  const c2 = t(2, 0);
  const cube = useSpringAt(0, 'bouncy');
  const h1Out = useRamp(c2 - 4, c2 + 6, 'in');

  return (
    <AbsoluteFill>
      {[0, 1, 2].map((i) => (
        <Ring key={i} start={c2} i={i} />
      ))}

      {SATS.map((name, i) => {
        const a = ((-90 + i * 60) * Math.PI) / 180;
        return (
          <div key={name} style={centerAt(CX + Math.cos(a) * 640, CY + Math.sin(a) * 270)}>
            <Entrance delay={c2 + 4 + i * 4} y={0} scaleFrom={0.3} kind="bouncy">
              <IconTile name={name} size={120} accent={i === 2} />
            </Entrance>
          </div>
        );
      })}

      <div
        style={{
          ...centerAt(CX, CY + idle * 6), width: 220, height: 220, borderRadius: '50%',
          background: theme.colors.primary, boxShadow: theme.shadow.card,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          transform: `translate(-50%, -50%) scale(${cube})`,
        }}
      >
        <Icon name="box" size={110} color={theme.colors.surface} />
      </div>

      {/* cue 1: "Shopify dropshipping" */}
      <div
        style={{
          position: 'absolute', left: 0, width: 1920, top: 620, opacity: 1 - h1Out,
          transform: `translateY(${-h1Out * 30}px)`,
        }}
      >
        <WordReveal text="*ড্রপশিপিং*" size={200} delay={6} />
        <Entrance delay={20} y={20} style={{display: 'flex', justifyContent: 'center', marginTop: 14}}>
          <div
            style={{
              padding: '10px 36px', borderRadius: theme.radius.pill,
              background: theme.colors.primarySoft,
            }}
          >
            <Label size={44} weight={600} color={theme.colors.primary}>Shopify</Label>
          </div>
        </Entrance>
      </div>

      {/* cue 2: it is not limited to dropshipping */}
      <div style={{position: 'absolute', left: 160, width: 1600, top: 770}}>
        <WordReveal text="ডিজিটাল ব্যবসার জগত *শুধু ড্রপশিপিং* নয়" size={88} delay={c2 + 2} per={4} />
      </div>
    </AbsoluteFill>
  );
};
