import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame} from 'remotion';
import {theme} from '../theme';
import {Entrance, WordReveal, useIdle, useRamp, useSpringAt} from '../components/Motion';
import {Cursor, Icon, Label} from '../components/ui';
import {useCue} from '../lib/timing';

const Skeleton: React.FC<{w: number; h?: number; dark?: boolean}> = ({w, h = 14, dark}) => (
  <div style={{width: w, height: h, borderRadius: h, background: dark ? theme.colors.gloss : theme.colors.line}} />
);

const Product: React.FC<{x: number; hot?: boolean; press: number}> = ({x, hot, press}) => (
  <div
    style={{
      position: 'absolute', left: x, top: 310, width: 254, height: 270, boxSizing: 'border-box',
      borderRadius: 22, background: theme.colors.surface, border: `1px solid ${theme.colors.line}`, padding: 16,
    }}
  >
    <div style={{height: 120, borderRadius: 14, background: theme.colors.primarySoft, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
      <Icon name="box" size={56} color={theme.colors.primary} />
    </div>
    <div style={{marginTop: 14, display: 'flex', flexDirection: 'column', gap: 8}}>
      <Skeleton w={170} />
      <Skeleton w={110} h={10} />
    </div>
    <div
      style={{
        position: 'absolute', left: 16, right: 16, bottom: 16, height: 54, borderRadius: 14,
        background: hot ? theme.colors.accent : theme.colors.primary,
        transform: hot ? `scale(${1 - press * 0.08})` : undefined,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontFamily: theme.fonts.display, fontSize: 24, fontWeight: 600, color: theme.colors.surface, letterSpacing: 0,
      }}
    >
      Add to cart
    </div>
  </div>
);

export const Store: React.FC = () => {
  const frame = useCurrentFrame();
  const t = useCue();
  const idle = useIdle(28);
  const win = useSpringAt(4, 'smooth');
  const click = t(9, 0.55);
  const cursorIn = useRamp(t(9, 0.18), click - 2, 'inOut');
  const press = interpolate(frame, [click, click + 4, click + 10], [0, 1, 0], {
    extrapolateLeft: 'clamp', extrapolateRight: 'clamp',
  });
  const toast = useSpringAt(click + 4, 'bouncy');

  return (
    <AbsoluteFill>
      <div style={{position: 'absolute', left: 140, top: 290, width: 760}}>
        <WordReveal text="ড্রপশিপিং শিখে নিজের *অনলাইন বিজনেস* পরিচালনা" size={88} delay={2} align="flex-start" />
      </div>

      <div style={{position: 'absolute', left: 940, top: 190 + idle * 6, width: 860, height: 640, perspective: 2200}}>
        <div
          style={{
            width: '100%', height: '100%', position: 'relative', borderRadius: 30, overflow: 'hidden',
            background: theme.colors.bgAlt, boxShadow: theme.shadow.card, border: `1px solid ${theme.colors.line}`,
            opacity: Math.min(1, win * 1.4),
            transform: `translateX(${(1 - win) * 120}px) rotateY(${-9 + (1 - win) * 12}deg) rotateX(4deg)`,
          }}
        >
          {/* browser bar */}
          <div style={{height: 64, background: theme.colors.surface, display: 'flex', alignItems: 'center', gap: 10, padding: '0 24px', borderBottom: `1px solid ${theme.colors.line}`}}>
            {[0, 1, 2].map((i) => (
              <div key={i} style={{width: 14, height: 14, borderRadius: '50%', background: i === 0 ? theme.colors.accent : theme.colors.line}} />
            ))}
            <div style={{marginLeft: 20, height: 34, width: 320, borderRadius: 17, background: theme.colors.bg, display: 'flex', alignItems: 'center', paddingLeft: 18}}>
              <Label size={22} weight={500} color={theme.colors.textDim}>yourstore.com</Label>
            </div>
          </div>
          {/* hero banner */}
          <div style={{position: 'absolute', left: 28, top: 92, width: 804, height: 190, borderRadius: 22, background: theme.colors.primary, padding: 30, boxSizing: 'border-box'}}>
            <Skeleton w={300} h={22} dark />
            <div style={{height: 14}} />
            <Skeleton w={200} h={14} dark />
            <div style={{marginTop: 26, width: 150, height: 46, borderRadius: 23, background: theme.colors.accent}} />
          </div>
          <Product x={28} press={0} />
          <Product x={302} hot press={press} />
          <Product x={576} press={0} />
          {/* gloss */}
          <div style={{position: 'absolute', inset: 0, pointerEvents: 'none', background: `linear-gradient(120deg, ${theme.colors.gloss}, transparent 38%)`}} />
          {/* toast */}
          <div
            style={{
              position: 'absolute', right: 28, top: 84, display: 'flex', alignItems: 'center', gap: 14,
              padding: '14px 26px', borderRadius: 20, background: theme.colors.surface, boxShadow: theme.shadow.soft,
              opacity: Math.min(1, toast), transform: `translateY(${(1 - toast) * -30}px) scale(${0.9 + 0.1 * toast})`,
            }}
          >
            <div style={{width: 40, height: 40, borderRadius: '50%', background: theme.colors.accent, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
              <Icon name="check" size={24} color={theme.colors.surface} stroke={2.6} />
            </div>
            <Label size={30}>নতুন অর্ডার</Label>
          </div>
          {/* cursor */}
          <div
            style={{
              position: 'absolute', left: 820 - cursorIn * 380, top: 640 - cursorIn * 90,
              opacity: Math.min(1, cursorIn * 4),
            }}
          >
            <Cursor size={54} />
          </div>
        </div>
      </div>
    </AbsoluteFill>
  );
};
