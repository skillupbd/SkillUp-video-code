import React from 'react';
import {AbsoluteFill} from 'remotion';
import {theme} from '../theme';
import {WordReveal, useIdle, useRamp, useSpringAt} from '../components/Motion';
import {Logo, centerAt} from '../components/ui';

export const Brand: React.FC = () => {
  const idle = useIdle(22);
  const pop = useSpringAt(4, 'bouncy');
  const rot = useRamp(4, 40, 'out');
  const ring = useRamp(8, 46, 'out');
  return (
    <AbsoluteFill>
      <div
        style={{
          ...centerAt(960, 400), width: 440, height: 440, borderRadius: '50%',
          border: `6px solid ${theme.colors.accent}`, opacity: ring > 0 ? (1 - ring) * 0.6 : 0,
          transform: `translate(-50%, -50%) scale(${1 + ring * 0.9})`,
        }}
      />
      <div
        style={{
          ...centerAt(960, 400),
          transform: `translate(-50%, -50%) scale(${(0.5 + 0.5 * pop) * (1 + idle * 0.015)}) rotate(${(1 - rot) * -14}deg)`,
          opacity: Math.min(1, pop * 1.5),
          filter: `drop-shadow(0 0 40px ${theme.colors.glow})`,
        }}
      >
        <Logo size={440} />
      </div>
      <div style={{position: 'absolute', left: 160, width: 1600, top: 690}}>
        <WordReveal text="এখানেই স্কিল আপ-এর *বিশেষত্ব*" size={96} delay={16} per={4} />
      </div>
    </AbsoluteFill>
  );
};
