import React from 'react';
import {AbsoluteFill} from 'remotion';
import {theme} from '../theme';
import {Entrance, WordReveal, useIdle, useRamp, useSpringAt} from '../components/Motion';
import {DrawLine, Icon, IconName, IconTile, Label, cardStyle, centerAt} from '../components/ui';
import {useCue} from '../lib/timing';

const C = {x: 480, y: 600};
const ITEMS: {icon: IconName; title: string; sub: string; y: number}[] = [
  {icon: 'layout', title: 'ওয়েবসাইট তৈরি', sub: 'Website Building', y: 230},
  {icon: 'store', title: 'স্টোর সেটআপ', sub: 'Store Setup', y: 450},
  {icon: 'search', title: 'প্রোডাক্ট রিসার্চ', sub: 'Product Research', y: 670},
  {icon: 'megaphone', title: 'ডিজিটাল মার্কেটিং', sub: 'Digital Marketing', y: 890},
];

const Branch: React.FC<{item: (typeof ITEMS)[number]; delay: number}> = ({item, delay}) => {
  const p = useRamp(delay - 4, delay + 20, 'out');
  return (
    <g opacity={0.35}>
      <DrawLine d={`M ${C.x + 170} ${C.y} C 800 ${C.y}, 800 ${item.y}, 1090 ${item.y}`} progress={p} width={5} />
    </g>
  );
};

const Chip: React.FC<{item: (typeof ITEMS)[number]; delay: number}> = ({item, delay}) => {
  const idle = useIdle(30, item.y);
  return (
    <div style={{position: 'absolute', left: 1090, top: item.y + idle * 3, transform: 'translateY(-50%)'}}>
      <Entrance delay={delay} x={60} y={0} kind="snappy" scaleFrom={0.9}>
        <div style={{...cardStyle(), width: 660, padding: '20px 32px', display: 'flex', alignItems: 'center', gap: 26, boxSizing: 'border-box'}}>
          <IconTile name={item.icon} size={90} dark />
          <div>
            <Label size={44}>{item.title}</Label>
            <Label size={26} weight={500} color={theme.colors.textDim}>{item.sub}</Label>
          </div>
        </div>
      </Entrance>
    </div>
  );
};

export const Services: React.FC = () => {
  const t = useCue();
  const idle = useIdle(24);
  const hub = useSpringAt(0, 'bouncy');
  const ring = useRamp(4, 50, 'out');
  return (
    <AbsoluteFill>
      <div style={{position: 'absolute', left: 130, top: 90, width: 700}}>
        <WordReveal text="দক্ষতা কাজে লাগিয়ে *অন্যদেরও*" size={64} delay={2} align="flex-start" />
      </div>
      <svg width={1920} height={1080} style={{position: 'absolute', left: 0, top: 0}}>
        {ITEMS.map((it, i) => (
          <Branch key={i} item={it} delay={t(10, i / 4)} />
        ))}
      </svg>
      <div
        style={{
          ...centerAt(C.x, C.y), width: 340, height: 340, borderRadius: '50%',
          border: `5px solid ${theme.colors.accent}`, opacity: ring > 0 ? (1 - ring) * 0.5 : 0,
          transform: `translate(-50%, -50%) scale(${1 + ring * 0.5})`,
        }}
      />
      <div
        style={{
          ...centerAt(C.x, C.y + idle * 5), width: 340, height: 340, borderRadius: '50%',
          background: theme.colors.primary, boxShadow: theme.shadow.card,
          display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 6,
          transform: `translate(-50%, -50%) scale(${hub})`,
        }}
      >
        <Icon name="users" size={130} color={theme.colors.surface} stroke={1.6} />
        <Label size={46} color={theme.colors.onPrimary}>অন্যদের সার্ভিস</Label>
      </div>
      {ITEMS.map((it, i) => (
        <Chip key={i} item={it} delay={t(10, i / 4)} />
      ))}
    </AbsoluteFill>
  );
};
