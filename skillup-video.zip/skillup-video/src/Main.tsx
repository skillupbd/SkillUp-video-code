import React from 'react';
import {AbsoluteFill, Sequence} from 'remotion';
import {BgMesh, Grade, Grain, Vignette} from './components/Layers';
import {SceneFrame} from './components/Motion';
import {PreviewAudio, SfxLayer} from './components/Sfx';
import {OVERLAP, SceneId, scenes} from './lib/timing';
import {Hook} from './scenes/Hook';
import {Brand} from './scenes/Brand';
import {Hub} from './scenes/Hub';
import {Split} from './scenes/Split';
import {Bento} from './scenes/Bento';
import {Think} from './scenes/Think';
import {Store} from './scenes/Store';
import {Services} from './scenes/Services';
import {Flow} from './scenes/Flow';
import {Carousel} from './scenes/Carousel';
import {Recap} from './scenes/Recap';
import {Cta} from './scenes/Cta';

export type MainProps = {voiceoverOnRender: boolean};

const COMPONENTS: Record<SceneId, React.FC> = {
  hook: Hook, brand: Brand, hub: Hub, split: Split, bento: Bento, think: Think,
  store: Store, services: Services, flow: Flow, carousel: Carousel, recap: Recap, cta: Cta,
};

export const Main: React.FC<MainProps> = ({voiceoverOnRender}) => (
  <AbsoluteFill>
    {/* 1. background mesh */}
    <BgMesh />
    {/* 2-3. scenes (assets + graphics/type) */}
    {scenes.map((s, i) => {
      const Comp = COMPONENTS[s.id];
      const last = i === scenes.length - 1;
      return (
        <Sequence key={s.id} from={s.from} durationInFrames={s.to - s.from + (last ? 0 : OVERLAP)}>
          <SceneFrame from={s.from} last={last}>
            <Comp />
          </SceneFrame>
        </Sequence>
      );
    })}
    {/* 4. grade, 5. grain + vignette */}
    <Grade />
    <Grain />
    <Vignette />
    <SfxLayer />
    <PreviewAudio voiceoverOnRender={voiceoverOnRender} />
  </AbsoluteFill>
);
