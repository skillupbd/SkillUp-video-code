// All timing is derived from the SRT cues. Nothing is hand-timed.
import {createContext, useContext} from 'react';
import {parseSrt} from './srt';
import {SRT_TEXT} from '../data/subtitles';

export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;
/** Visuals enter ~5 frames before the narration that refers to them. */
export const LEAD = 5;
/** Outgoing scene overlaps the next one by this many frames (its exit). */
export const OVERLAP = 10;

export const cues = parseSrt(SRT_TEXT);
export const cueStart = (n: number) => Math.round(cues[n - 1].start * FPS);
export const cueEnd = (n: number) => Math.round(cues[n - 1].end * FPS);
export const cueLen = (n: number) => cueEnd(n) - cueStart(n);
export const TOTAL_FRAMES = cueEnd(cues.length);

/** Absolute frame of a point inside a cue (frac 0..1), minus the lead. */
export const absAt = (cue: number, frac = 0, lead = LEAD) =>
  cueStart(cue) + Math.round(cueLen(cue) * frac) - lead;

export type SceneId =
  | 'hook' | 'brand' | 'hub' | 'split' | 'bento' | 'think'
  | 'store' | 'services' | 'flow' | 'carousel' | 'recap' | 'cta';

const DEFS: {id: SceneId; cues: number[]}[] = [
  {id: 'hook', cues: [1, 2]},
  {id: 'brand', cues: [3]},
  {id: 'hub', cues: [4]},
  {id: 'split', cues: [5]},
  {id: 'bento', cues: [6, 7]},
  {id: 'think', cues: [8]},
  {id: 'store', cues: [9]},
  {id: 'services', cues: [10]},
  {id: 'flow', cues: [11, 12]},
  {id: 'carousel', cues: [13, 14, 15]},
  {id: 'recap', cues: [16, 17]},
  {id: 'cta', cues: [18, 19]},
];

export const scenes = DEFS.map((d, i) => ({
  ...d,
  from: i === 0 ? 0 : cueStart(d.cues[0]) - LEAD,
})).map((s, i, arr) => ({
  ...s,
  to: i === arr.length - 1 ? TOTAL_FRAMES : arr[i + 1].from,
}));

export const SceneCtx = createContext<number>(0);

/** Returns t(cue, frac, lead) = frame relative to the current scene start. */
export const useCue = () => {
  const from = useContext(SceneCtx);
  return (cue: number, frac = 0, lead = LEAD) => absAt(cue, frac, lead) - from;
};
