export type Cue = {index: number; start: number; end: number; text: string};

const toSeconds = (t: string): number => {
  const m = t.trim().match(/(\d+):(\d+):(\d+)[,.](\d+)/);
  if (!m) throw new Error(`Bad SRT time: ${t}`);
  return Number(m[1]) * 3600 + Number(m[2]) * 60 + Number(m[3]) + Number(m[4]) / 1000;
};

export const parseSrt = (src: string): Cue[] =>
  src
    .replace(/\r/g, '')
    .trim()
    .split(/\n\s*\n/)
    .map((block) => {
      const lines = block.split('\n');
      const [a, b] = lines[1].split('-->');
      return {
        index: parseInt(lines[0], 10),
        start: toSeconds(a),
        end: toSeconds(b),
        text: lines.slice(2).join(' ').trim(),
      };
    });
