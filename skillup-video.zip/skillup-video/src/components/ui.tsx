import React from 'react';
import {Img, staticFile} from 'remotion';
import {theme} from '../theme';

export type IconName =
  | 'search' | 'store' | 'megaphone' | 'code' | 'plus' | 'box' | 'globe' | 'briefcase'
  | 'check' | 'arrow' | 'users' | 'trend' | 'cursor' | 'layout' | 'spark';

const PATHS: Record<IconName, string[]> = {
  search: ['M11 4a7 7 0 100 14 7 7 0 000-14z', 'M16.5 16.5L21 21'],
  store: ['M4 9h16v11H4z', 'M3 9l2-5h14l2 5', 'M9 20v-6h6v6'],
  megaphone: ['M3 11v2a1 1 0 001 1h2l5 4V6L6 10H4a1 1 0 00-1 1z', 'M15 9a4 4 0 010 6', 'M18 6.5a8 8 0 010 11'],
  code: ['M8 7l-5 5 5 5', 'M16 7l5 5-5 5', 'M14 5l-4 14'],
  plus: ['M12 4v16', 'M4 12h16'],
  box: ['M3 7l9-4 9 4v10l-9 4-9-4z', 'M3 7l9 4 9-4', 'M12 11v10'],
  globe: ['M12 3a9 9 0 100 18 9 9 0 000-18z', 'M3 12h18', 'M12 3a14 14 0 010 18', 'M12 3a14 14 0 000 18'],
  briefcase: ['M3 7h18v13H3z', 'M9 7V5a2 2 0 012-2h2a2 2 0 012 2v2', 'M3 13h18'],
  check: ['M5 12l5 5 10-11'],
  arrow: ['M4 12h16', 'M14 6l6 6-6 6'],
  users: ['M9 5a3.5 3.5 0 100 7 3.5 3.5 0 000-7z', 'M2.5 20a6.5 6.5 0 0113 0', 'M17 7a2.5 2.5 0 110 5', 'M16 14a5 5 0 016 5'],
  trend: ['M3 17l6-6 4 4 8-8', 'M15 7h6v6'],
  cursor: ['M5 3l14 8-6 2-2 6z'],
  layout: ['M3 4h18v16H3z', 'M3 9h18', 'M7 6.5h.01'],
  spark: ['M12 3l2.2 6.8L21 12l-6.8 2.2L12 21l-2.2-6.8L3 12l6.8-2.2z'],
};

export const Icon: React.FC<{name: IconName; size?: number; color?: string; stroke?: number; fill?: string}> = ({
  name, size = 48, color = theme.colors.primary, stroke = 1.8, fill = 'none',
}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill={fill} stroke={color}
    strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round">
    {PATHS[name].map((d, i) => (
      <path key={i} d={d} />
    ))}
  </svg>
);

/** Rounded icon tile. */
export const IconTile: React.FC<{name: IconName; size?: number; dark?: boolean; accent?: boolean}> = ({
  name, size = 96, dark = false, accent = false,
}) => (
  <div
    style={{
      width: size, height: size, borderRadius: size * 0.3, display: 'flex',
      alignItems: 'center', justifyContent: 'center',
      background: accent ? theme.colors.accent : dark ? theme.colors.primary : theme.colors.primarySoft,
    }}
  >
    <Icon name={name} size={size * 0.52}
      color={accent || dark ? theme.colors.surface : theme.colors.primary} />
  </div>
);

/** White card surface. */
export const cardStyle = (dark = false): React.CSSProperties => ({
  background: dark ? theme.colors.primary : theme.colors.surface,
  borderRadius: theme.radius.card,
  boxShadow: theme.shadow.card,
  border: `1px solid ${dark ? 'transparent' : theme.colors.line}`,
});

export const Label: React.FC<{
  size: number; weight?: number; color?: string; style?: React.CSSProperties; children: React.ReactNode;
}> = ({size, weight = 700, color = theme.colors.text, style, children}) => (
  <div
    style={{
      fontFamily: theme.fonts.display, fontSize: size, fontWeight: weight, color,
      lineHeight: 1.3, letterSpacing: 0, ...style,
    }}
  >
    {children}
  </div>
);

/** The supplied logo. It is a circular badge: shown 1:1, never redrawn or stretched. */
export const Logo: React.FC<{size: number; style?: React.CSSProperties}> = ({size, style}) => (
  <div
    style={{
      width: size, height: size, borderRadius: '50%', overflow: 'hidden',
      boxShadow: theme.shadow.card, background: theme.colors.surface, ...style,
    }}
  >
    <Img src={staticFile('logo.jpg')} style={{width: '100%', height: '100%', objectFit: 'contain'}} />
  </div>
);

/** Mouse cursor graphic. */
export const Cursor: React.FC<{size?: number}> = ({size = 56}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" style={{filter: `drop-shadow(0 6px 8px ${theme.colors.primarySoft})`}}>
    <path d="M5 3l14 8-6 2-2 6z" fill={theme.colors.primary} stroke={theme.colors.surface} strokeWidth={1.4} strokeLinejoin="round" />
  </svg>
);

/** A curved or straight connector that draws itself (progress 0..1). */
export const DrawLine: React.FC<{d: string; progress: number; width?: number; color?: string; dashed?: boolean}> = ({
  d, progress, width = 4, color = theme.colors.primary, dashed = false,
}) => (
  <path
    d={d} fill="none" stroke={color} strokeWidth={width} strokeLinecap="round"
    pathLength={1}
    strokeDasharray={dashed ? '0.012 0.02' : 1}
    strokeDashoffset={dashed ? 0 : 1 - progress}
    opacity={dashed ? progress : 1}
  />
);

/** Positions an element by its CENTER at (x, y) on the 1920x1080 stage. */
export const centerAt = (x: number, y: number): React.CSSProperties => ({
  position: 'absolute', left: x, top: y, transform: 'translate(-50%, -50%)',
});
