import React, {useEffect, useState} from 'react';
import {Audio, Sequence, staticFile, useRemotionEnvironment} from 'remotion';
import {absAt, scenes} from '../lib/timing';
import {PREVIEW_VOICEOVER} from '../config';

type Sound = 'whoosh' | 'pop' | 'click' | 'chime' | 'thud';
type Ev = {f: number; s: Sound; v: number; rate?: number};

const sc = (id: string) => scenes.find((s) => s.id === id)!.from;

/**
 * Small, restrained SFX kit (5 effects, volume ~0.2-0.35).
 * One sound per major event: scene transitions, main entries, card / logo reveals.
 * (Staggered items never get their own sound.)
 */
const events: Ev[] = [
  {f: 3, s: 'thud', v: 0.3},
  {f: absAt(2, 0), s: 'pop', v: 0.28},
  // scene transitions: soft whoosh starting a little before each cut
  ...scenes.slice(1).map((s, i): Ev => ({f: s.from - 3, s: 'whoosh', v: 0.22, rate: i % 2 ? 1.08 : 0.96})),
  {f: sc('brand') + 6, s: 'chime', v: 0.3},
  {f: sc('hub') + 8, s: 'pop', v: 0.26},
  {f: absAt(5, 0), s: 'pop', v: 0.26, rate: 1.05},
  {f: absAt(5, 1 / 3), s: 'pop', v: 0.24, rate: 0.95},
  {f: absAt(6, 0), s: 'pop', v: 0.26},
  {f: absAt(7, 0), s: 'pop', v: 0.26, rate: 1.1},
  {f: sc('think') + 8, s: 'thud', v: 0.26},
  {f: absAt(9, 0.55), s: 'click', v: 0.3},
  {f: absAt(10, 0), s: 'pop', v: 0.26, rate: 0.95},
  {f: absAt(11, 1 / 3), s: 'pop', v: 0.26},
  {f: absAt(12, 0.5), s: 'chime', v: 0.28, rate: 1.1},
  {f: absAt(13, 0), s: 'pop', v: 0.26},
  {f: absAt(13, 0.5), s: 'whoosh', v: 0.2, rate: 1.1},
  {f: absAt(14, 0), s: 'whoosh', v: 0.2, rate: 1.0},
  {f: absAt(15, 0.7), s: 'click', v: 0.3, rate: 0.95},
  {f: absAt(16, 0.75), s: 'pop', v: 0.26},
  {f: absAt(17, 0), s: 'chime', v: 0.26, rate: 0.95},
  {f: absAt(18, 0.55), s: 'click', v: 0.32},
  {f: absAt(19, 0.05), s: 'chime', v: 0.32, rate: 1.05},
];

const DUR: Record<Sound, number> = {whoosh: 26, pop: 10, click: 6, chime: 20, thud: 12};

export const SfxLayer: React.FC = () => (
  <>
    {events.map((e, i) => (
      <Sequence key={i} from={Math.max(0, e.f)} durationInFrames={DUR[e.s] + 4} layout="none">
        <Audio src={staticFile(`sfx/${e.s}.wav`)} volume={e.v} playbackRate={e.rate ?? 1} />
      </Sequence>
    ))}
  </>
);

/**
 * Plays public/voiceover.mp3 when the file exists. Studio preview: controlled by
 * PREVIEW_VOICEOVER. Rendering: OFF by default (pass --props='{"voiceoverOnRender":true}').
 */
export const PreviewAudio: React.FC<{voiceoverOnRender: boolean}> = ({voiceoverOnRender}) => {
  const {isRendering} = useRemotionEnvironment();
  const wanted = isRendering ? voiceoverOnRender : PREVIEW_VOICEOVER;
  const [exists, setExists] = useState(false);

  useEffect(() => {
    if (!wanted) return;
    let alive = true;
    fetch(staticFile('voiceover.mp3'), {method: 'HEAD'})
      .then((r) => alive && setExists(r.ok && (r.headers.get('content-type') ?? '').includes('audio')))
      .catch(() => alive && setExists(false));
    return () => {
      alive = false;
    };
  }, [wanted]);

  if (!wanted || !exists) return null;
  return <Audio src={staticFile('voiceover.mp3')} volume={1} />;
};
