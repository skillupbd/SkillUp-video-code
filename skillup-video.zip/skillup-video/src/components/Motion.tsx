import React, {useContext} from 'react';
import {AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {theme} from '../theme';
import {SceneCtx} from '../lib/timing';

type SpringKind = keyof typeof theme.spring;

/** Spring progress 0..1 (can overshoot for bouncy) starting at `delay`. */
export const useSpringAt = (delay: number, kind: SpringKind = 'smooth') => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  return spring({frame: Math.max(0, frame - delay), fps, config: theme.spring[kind]});
};

/** Linear-free eased 0..1 ramp between two frames. */
export const useRamp = (from: number, to: number, ease: 'out' | 'in' | 'inOut' = 'out') => {
  const frame = useCurrentFrame();
  return interpolate(frame, [from, to], [0, 1], {
    easing: theme.ease[ease],
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
};

/** Idle breathing value in -1..1. */
export const useIdle = (speed = 30, phase = 0) => {
  const frame = useCurrentFrame();
  return Math.sin(frame / speed + phase);
};

/** Premium entrance: opacity + translate + scale together. */
export const Entrance: React.FC<{
  delay?: number; x?: number; y?: number; scaleFrom?: number;
  kind?: SpringKind; style?: React.CSSProperties; children?: React.ReactNode;
}> = ({delay = 0, x = 0, y = 40, scaleFrom = 0.94, kind = 'smooth', style, children}) => {
  const p = useSpringAt(delay, kind);
  const o = interpolate(p, [0, 1], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  return (
    <div
      style={{
        opacity: o,
        transform: `translate(${(1 - p) * x}px, ${(1 - p) * y}px) scale(${scaleFrom + (1 - scaleFrom) * p})`,
        ...style,
      }}
    >
      {children}
    </div>
  );
};

/**
 * Word-by-word reveal. Words split ONLY on spaces (Bengali conjuncts are never
 * split), letterSpacing 0. A word starting with "*" is highlighted in the accent
 * colour with a highlight sweep.
 */
export const WordReveal: React.FC<{
  text: string; size: number; delay?: number; per?: number; weight?: number;
  color?: string; align?: 'center' | 'flex-start' | 'flex-end'; style?: React.CSSProperties;
}> = ({text, size, delay = 0, per = 4, weight = 700, color = theme.colors.text, align = 'center', style}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  // "*word*" or "*two words*" marks accent words (state carries across words).
  let open = false;
  const parsed = text.split(' ').filter(Boolean).map((raw) => {
    let w = raw;
    if (w.startsWith('*')) {
      open = true;
      w = w.slice(1);
    }
    const hot = open;
    if (w.endsWith('*')) {
      open = false;
      w = w.slice(0, -1);
    }
    return {w, hot};
  });
  return (
    <div
      style={{
        display: 'flex', flexWrap: 'wrap', justifyContent: align,
        columnGap: Math.round(size * 0.28), rowGap: Math.round(size * 0.06),
        fontFamily: theme.fonts.display, fontSize: size, fontWeight: weight,
        lineHeight: 1.3, letterSpacing: 0, ...style,
      }}
    >
      {parsed.map(({w, hot}, i) => {
        const d = delay + i * per;
        const p = spring({frame: Math.max(0, frame - d), fps, config: theme.spring.snappy});
        const sweep = interpolate(frame, [d + 5, d + 20], [0, 1], {
          easing: theme.ease.out, extrapolateLeft: 'clamp', extrapolateRight: 'clamp',
        });
        return (
          <span
            key={i}
            style={{
              position: 'relative', display: 'inline-block',
              opacity: interpolate(p, [0, 1], [0, 1], {extrapolateRight: 'clamp'}),
              transform: `translateY(${(1 - p) * 30}px)`,
              color: hot ? theme.colors.accent : color,
            }}
          >
            {hot && (
              <span
                style={{
                  position: 'absolute', left: 0, bottom: size * 0.1, height: size * 0.22,
                  width: `${sweep * 100}%`, background: theme.colors.accentSoft,
                  borderRadius: 8, zIndex: -1,
                }}
              />
            )}
            {w}
          </span>
        );
      })}
    </div>
  );
};

/** Wraps a scene: exit (faster than entrance) in its last OVERLAP frames. */
export const SceneFrame: React.FC<{from: number; last?: boolean; children: React.ReactNode}> = ({
  from, last, children,
}) => {
  const frame = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();
  const exit = last
    ? 0
    : interpolate(frame, [durationInFrames - 10, durationInFrames - 1], [0, 1], {
        easing: theme.ease.in, extrapolateLeft: 'clamp', extrapolateRight: 'clamp',
      });
  return (
    <SceneCtx.Provider value={from}>
      <AbsoluteFill
        style={{
          opacity: 1 - exit,
          transform: `translateY(${-30 * exit}px) scale(${1 + 0.02 * exit})`,
          filter: exit > 0 ? `blur(${exit * 6}px)` : undefined,
        }}
      >
        {children}
      </AbsoluteFill>
    </SceneCtx.Provider>
  );
};

export const useSceneStart = () => useContext(SceneCtx);
