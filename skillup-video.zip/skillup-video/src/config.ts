/** Studio preview: play public/voiceover.mp3 (if the file exists). */
export const PREVIEW_VOICEOVER = true;
