// Hind Siliguri: correct Bengali conjuncts (juktakkhor) and kar-signs.
// Loaded through @remotion/google-fonts (bundled with the package, works for render).
import {loadFont} from '@remotion/google-fonts/HindSiliguri';

export const {fontFamily} = loadFont('normal', {
  weights: ['400', '500', '600', '700'],
  subsets: ['bengali', 'latin'],
});
