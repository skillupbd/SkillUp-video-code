import React from 'react';
import {Composition} from 'remotion';
import {Main} from './Main';
import {FPS, HEIGHT, TOTAL_FRAMES, WIDTH} from './lib/timing';

export const RemotionRoot: React.FC = () => (
  <Composition
    id="Main"
    component={Main}
    durationInFrames={TOTAL_FRAMES}
    fps={FPS}
    width={WIDTH}
    height={HEIGHT}
    defaultProps={{voiceoverOnRender: false}}
  />
);
