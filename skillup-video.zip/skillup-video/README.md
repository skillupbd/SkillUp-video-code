# SkillUp Video (Remotion)

Entry file: `src/index.ts` - Composition ID: `Main` (1920x1080, 30fps, 3233 frames from the SRT)

    npm install
    npx remotion studio
    npx remotion render src/index.ts Main out/video.mp4

- Timing comes only from `src/data/subtitles.ts` (the SRT). Colours / easing / fonts live in `src/theme.ts`.
- `public/voiceover.mp3` plays in Studio preview only. Off when rendering; to include it:
  `npx remotion render src/index.ts Main out/video.mp4 --props='{"voiceoverOnRender":true}'`
- SFX are in `public/sfx/` (regenerate with `npm run sfx`, needs python3 + numpy + scipy).
