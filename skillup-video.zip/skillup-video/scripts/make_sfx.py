#!/usr/bin/env python3
"""Synthesises the small UI sound-effect kit into public/sfx/ (16-bit mono WAV, 44.1 kHz).
Deterministic (fixed seed). Usage: python3 scripts/make_sfx.py"""
import os, wave
import numpy as np
from scipy.signal import butter, sosfilt

SR = 44100
OUT = os.path.join(os.path.dirname(__file__), '..', 'public', 'sfx')
os.makedirs(OUT, exist_ok=True)
rng = np.random.default_rng(7)

def t_axis(d): return np.arange(int(SR * d)) / SR
def lp(x, f): return sosfilt(butter(2, f, 'low', fs=SR, output='sos'), x)
def hp(x, f): return sosfilt(butter(2, f, 'high', fs=SR, output='sos'), x)
def env(n, attack, tau):
    t = np.arange(n) / SR
    a = np.clip(t / attack, 0, 1) ** 2
    return a * np.exp(-t / tau)
def tiny_reverb(x):
    y = x.copy()
    for delay, g in ((0.031, 0.14), (0.057, 0.09), (0.083, 0.05)):
        d = int(delay * SR)
        y[d:] += lp(x, 3500)[:-d] * g
    return y
def fade_end(x, ms=12):
    n = int(SR * ms / 1000); x = x.copy(); x[-n:] *= np.linspace(1, 0, n); return x

def pop():
    t = t_axis(0.24)
    f = 180 + 360 * np.exp(-t / 0.035)               # fast falling pitch
    ph = 2 * np.pi * np.cumsum(f) / SR
    x = (np.sin(ph) + 0.18 * np.sin(2 * ph)) * env(len(t), 0.004, 0.055)
    return lp(x, 4200)

def click():
    t = t_axis(0.14)
    n = hp(rng.standard_normal(len(t)), 2200) * env(len(t), 0.0008, 0.011)
    body = np.sin(2 * np.pi * 1300 * t) * env(len(t), 0.001, 0.012) * 0.5
    return lp(n + body, 6500)

def whoosh():
    d = 0.75; n = int(SR * d); t = np.arange(n) / SR
    noise = rng.standard_normal(n); out = np.zeros(n); blk = 512
    for i in range(0, n, blk):                       # band-pass sweep, 350 -> 2800 Hz
        fc = 350 * (2800 / 350) ** ((i / n) ** 1.2)
        sos = butter(2, [fc * 0.7, fc * 1.35], 'band', fs=SR, output='sos')
        out[i:i + blk] = sosfilt(sos, noise[i:i + blk])
    e = np.sin(np.pi * np.clip(t / d, 0, 1)) ** 2.2   # fade in / fade out
    return lp(out * e, 5000)

def chime():
    t = t_axis(0.5)
    x = (np.sin(2 * np.pi * 880 * t) + 0.35 * np.sin(2 * np.pi * 1320 * t) + 0.12 * np.sin(2 * np.pi * 1760 * t))
    x *= env(len(t), 0.006, 0.13)
    return lp(x, 5000)

def thud():
    t = t_axis(0.3)
    f = 48 + 60 * np.exp(-t / 0.05)
    x = np.sin(2 * np.pi * np.cumsum(f) / SR) * env(len(t), 0.006, 0.09)
    return lp(x, 220)

KIT = {'pop': pop, 'click': click, 'whoosh': whoosh, 'chime': chime, 'thud': thud}
TARGET_RMS, PEAK_LIMIT = 0.10, 0.80

for name, fn in KIT.items():
    x = tiny_reverb(fn())
    x = fade_end(x)
    x *= TARGET_RMS / (np.sqrt(np.mean(x ** 2)) + 1e-9)   # similar loudness for all effects
    peak = np.max(np.abs(x))
    if peak > PEAK_LIMIT: x *= PEAK_LIMIT / peak           # never clip
    pcm = (np.clip(x, -1, 1) * 32767).astype('<i2')
    with wave.open(os.path.join(OUT, f'{name}.wav'), 'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes(pcm.tobytes())
    print(f'{name:7s} {len(x) / SR:.2f}s  peak {np.max(np.abs(x)):.2f}  rms {np.sqrt(np.mean(x ** 2)):.3f}')
